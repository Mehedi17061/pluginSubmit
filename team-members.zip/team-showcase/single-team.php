<?php
get_header();
if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <div class="team-member-single">
        <div class="team-member-header">
            <?php the_post_thumbnail('large'); ?>
            <h1><?php the_title(); ?></h1>
            <p><?php echo get_post_meta(get_the_ID(), 'team_position', true); ?></p>
        </div>
        <div class="team-member-bio">
            <?php the_content(); ?>
        </div>
    </div>
<?php endwhile; endif;
get_footer();
