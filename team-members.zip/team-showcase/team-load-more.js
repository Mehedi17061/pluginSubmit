

jQuery(document).ready(function($) {
    var page = 1;
    var loading = false;
    var hasMore = true;

    function loadMoreTeams() {
        if (loading || !hasMore) return;
        loading = true;

        $.ajax({
            url: team_load_more_params.ajax_url,
            type: 'GET',
            data: {
                action: 'load_more_team',
                page: page,
                order: team_load_more_params.order,
                img_position: team_load_more_params.img_position,
                columns: team_load_more_params.columns
            },
            success: function(response) {
                if (response.posts.length > 0) {
                    $('#team-members').append(response.posts.join(''));
                    page++;
                    hasMore = response.has_more;
                    loading = false;
                } else {
                    hasMore = false;
                }
            }
        });
    }

    $('#load-more').on('click', function() {
        loadMoreTeams();
    });

    loadMoreTeams(); // Initial load
});
