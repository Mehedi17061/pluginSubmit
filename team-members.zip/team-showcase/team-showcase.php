<?php
/*
Plugin Name: Team Members
Description: Showcase your team members easily with a shortcode. [team number="4" img_position="top|bottom"] 
Version: 1.0
Author: S M Mehedi Hasan 
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Register Custom Post Type for Team Members
function create_team_post_type() {
    $labels = array(
        'name' => 'Team Members',
        'singular_name' => 'Team Member',
        'add_new' => 'Add New',
        'add_new_item' => 'Add New Team Member',
        'edit_item' => 'Edit Team Member',
        'new_item' => 'New Team Member',
        'all_items' => 'All Team Members',
        'view_item' => 'View Team Member',
        'search_items' => 'Search Team Members',
        'not_found' => 'No team members found',
        'not_found_in_trash' => 'No team members found in Trash',
        'parent_item_colon' => '',
        'menu_name' => 'Teams'
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'team' ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 5,
        'supports' => array( 'title', 'editor', 'thumbnail' ),
        'register_meta_box_cb' => 'add_team_metaboxes'
    );

    register_post_type( 'team', $args );
}
add_action( 'init', 'create_team_post_type' );

function tm_register_taxonomy() {
    $labels = array(
        'name' => 'Member Types',
        'singular_name' => 'Member Type',
        'search_items' => 'Search Member Types',
        'all_items' => 'All Member Types',
        'parent_item' => 'Parent Member Type',
        'parent_item_colon' => 'Parent Member Type:',
        'edit_item' => 'Edit Member Type',
        'update_item' => 'Update Member Type',
        'add_new_item' => 'Add New Member Type',
        'new_item_name' => 'New Member Type Name',
        'menu_name' => 'Member Types',
    );

    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'member-type'),
    );

    register_taxonomy('member_type', array('team_member'), $args);
}

add_action('init', 'tm_register_taxonomy');

// Add Custom Meta Boxes
function add_team_metaboxes() {
    add_meta_box(
        'team_details',
        'Team Member Details',
        'team_details',
        'team',
        'normal',
        'high'
    );
}

function team_details() {
    global $post;

    // Nonce field for security
    wp_nonce_field( basename( __FILE__ ), 'team_nonce' );

    // Get current values
    $team_position = get_post_meta( $post->ID, 'team_position', true );

    // Display fields
    echo '<p><label for="team_position">Position:</label> ';
    echo '<input type="text" id="team_position" name="team_position" value="' . esc_attr( $team_position ) . '" /></p>';
}

function save_team_details( $post_id ) {
    // Verify nonce
    if ( ! isset( $_POST['team_nonce'] ) || ! wp_verify_nonce( $_POST['team_nonce'], basename( __FILE__ ) ) ) {
        return $post_id;
    }

    // Check autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return $post_id;
    }

    // Check permissions
    if ( 'team' == $_POST['post_type'] ) {
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return $post_id;
        }
    } else {
        if ( ! current_user_can( 'edit_page', $post_id ) ) {
            return $post_id;
        }
    }

    // Sanitize and save data
    $team_position = sanitize_text_field( $_POST['team_position'] );

    update_post_meta( $post_id, 'team_position', $team_position );
}
add_action( 'save_post', 'save_team_details' );

// Shortcode to Display Team Members
// Shortcode to Display Team Members
function team_shortcode( $atts ) {
    $atts = shortcode_atts(
        array(
            'columns' => 4,
            'order' => 'ASC',
            'color' => '#000000',
            'img_position' => 'top', // Add img_position attribute
        ),
        $atts,
        'team'
    );

    wp_enqueue_script( 'team-load-more', plugins_url( 'team-showcase/team-load-more.js' ), array( 'jquery' ), null, true );
    wp_localize_script( 'team-load-more', 'team_load_more_params', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'columns' => $atts['columns'],
        'order' => $atts['order'],
        'color' => $atts['color'],
        'initial_posts_per_page' => 4,
        'img_position' => $atts['img_position'], // Pass img_position to the script
    ) );

    $output = '<div class="team-container" style="color: ' . esc_attr( $atts['color'] ) . ';">';
    $output .= '<div id="team-members" class="team-row" style="display: flex; flex-wrap: wrap;"></div>';
    $output .= '<button id="load-more" data-page="1" style="display: block; margin: 20px auto; padding: 10px 20px;">Load More</button>';
    $output .= '</div>';

    return $output;
}
add_shortcode( 'team', 'team_shortcode' );


// Handle AJAX Request
function load_more_team() {
    $paged = $_GET['page'] ? intval($_GET['page']) : 1;
    $order = $_GET['order'] ? sanitize_text_field($_GET['order']) : 'ASC';
    $posts_per_page = 4;
    $img_position = $_GET['img_position'] ? sanitize_text_field($_GET['img_position']) : 'top';

    $query = new WP_Query( array(
        'post_type' => 'team',
        'posts_per_page' => $posts_per_page,
        'paged' => $paged,
        'orderby' => 'date',
        'order' => $order,
    ) );

    $posts = array();

    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            $post_data = array(
                'title' => get_the_title(),
                'link' => get_permalink(),
                'content' => get_the_content(),
                'thumbnail' => get_the_post_thumbnail_url(),
                'position' => get_post_meta( get_the_ID(), 'team_position', true ),
            );

            // Build HTML structure
            $post_html = '<div class="team-member" style="flex-basis: calc(86% / ' . esc_attr( $_GET['columns'] ) . ');">';
            if ( $img_position === 'top' ) {
                $post_html .= '<a href="' . esc_url( $post_data['link'] ) . '"><img src="' . esc_url( $post_data['thumbnail'] ) . '" alt="' . esc_attr( $post_data['title'] ) . '"></a>';
            }
            $post_html .= '<h3><a href="' . esc_url( $post_data['link'] ) . '">' . esc_html( $post_data['title'] ) . '</a></h3>';
            if ( $img_position === 'bottom' ) {
                $post_html .= '<a href="' . esc_url( $post_data['link'] ) . '"><img src="' . esc_url( $post_data['thumbnail'] ) . '" alt="' . esc_attr( $post_data['title'] ) . '"></a>';
            }
            $post_html .= '<p>' . esc_html( $post_data['position'] ) . '</p>';
            $post_html .= '<div class="team-content">' . wp_kses_post( $post_data['content'] ) . '</div>';
            $post_html .= '</div>';

            $posts[] = $post_html;
        }
        wp_reset_postdata();
    }

    wp_send_json( array(
        'posts' => $posts,
        'has_more' => $query->max_num_pages > $paged,
    ) );
}
add_action( 'wp_ajax_load_more_team', 'load_more_team' );
add_action( 'wp_ajax_nopriv_load_more_team', 'load_more_team' );

// Enqueue Styles and Scripts
function team_styles() {
    wp_enqueue_style( 'team-styles', plugins_url( 'team-showcase/team-styles.css' ) );
    wp_enqueue_script( 'team-load-more', plugins_url( 'team-showcase/team-load-more.js' ), array( 'jquery' ), null, true );
}
add_action( 'wp_enqueue_scripts', 'team_styles' );
